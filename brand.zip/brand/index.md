# EPHIX Brand Asset Index

Every file in this directory is a standalone asset or token document.

| Category | Files |
|---|---|
| Logos | `logos/ephix-master-reference.png`, `ephix-primary-full.png`, `ephix-white.png`, `ephix-black.png`, `ephix-icon.png` |
| Colors | `colors/tokens.css`, `colors/palette.svg` |
| Typography | `type/typography-system.svg` |
| UI | `ui/components.svg`, `ui/borders-dividers.svg`, `ui/loading-indicator.svg`, `ui/favicon-treatment.svg` |
| Icons | `icons/icon-set.svg` |
| Shapes and patterns | `shapes/blue-accent-shapes.svg`, `patterns/geometric-grid.svg` |
| Textures | `textures/distress-overlay.svg` |
| Backgrounds | `backgrounds/clean-dark.svg`, `backgrounds/detailed-branded.svg` |
| Social | `social/profile-square.png`, `social/profile-banner.png`, `social/stickers.svg`, `social/small-decorative-elements.svg` |

The supplied logo exports are copied from the existing source-faithful kit. They are not regenerated or redesigned here.
